# GitHubTestOER

## GitHub für Texte

... in Schule, Studium und Wissenschaft!

### Warum und wie sieht das aus/wie fühlt sich das an?

\[...\]

### Klingt gut? - Hier gehts zum Kurs in [HTML](https://github.com/pilotta314/GitHubTestOER/index.html), [PDF](https://github.com/pilotta314/GitHubTestOER/course.pdf) oder als [EPUB](https://github.com/pilotta314/GitHubTestOER/course.epub)

